plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false

    // ✅ Firebase Google services plugin
    id("com.google.gms.google-services") version "4.4.2" apply false
}
